package com.rpgclasses.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.rpgclasses.RpgClassesMod;
import com.rpgclasses.data.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RpgClassesMod.MODID, value = Dist.CLIENT)
public class ClientHud {
    @SubscribeEvent
    public static void onRender(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        RpgData d = ClientData.data;
        if (d.rpgClass == RpgClass.NONE) return;
        MatrixStack ms = e.getMatrixStack();

        // Barra de mana + nível
        int x = 6, y = 6;
        float frac = d.maxMana > 0 ? Math.min(1f, d.mana / d.maxMana) : 0f;
        AbstractGui.fill(ms, x - 1, y - 1, x + 101, y + 9, 0xAA000000);
        AbstractGui.fill(ms, x, y, x + (int) (100 * frac), y + 8, 0xFF3A7BFF);
        mc.font.drawShadow(ms, (int) d.mana + "/" + (int) d.maxMana, x + 2, y, 0xFFFFFF);
        mc.font.drawShadow(ms, d.rpgClass.displayName + " Lv " + d.level + "/" + d.cap() + " [" + d.rank.name() + "]",
                x, y + 12, 0xFFD700);

        // Slots de skill (canto inferior direito)
        int slots = SkillSpec.slots(d.rank);
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        for (int i = 0; i < slots; i++) {
            int x0 = w - 6 - (slots - i) * 26 + 4;
            int y0 = h - 30;
            AbstractGui.fill(ms, x0 - 1, y0 - 1, x0 + 23, y0 + 23, 0xAA000000);
            AbstractGui.fill(ms, x0, y0, x0 + 22, y0 + 22, 0xFF2B2B3A);
            SkillSpec s = d.skills[i];
            String label = s == null ? "-" : s.element().display.substring(0, Math.min(3, s.element().display.length()));
            mc.font.drawShadow(ms, label, x0 + 3, y0 + 7, s == null ? 0x777777 : 0xFFFFFF);
            mc.font.drawShadow(ms, Keys.SKILL[i].getTranslatedKeyMessage().getString(), x0 + 2, y0 + 13, 0xAAAAAA);
            if (s != null) {
                long left = ClientData.cdEnd[i] - ClientData.ticks;
                if (left > 0) {
                    int total = SkillMath.cooldown(d.rpgClass, s);
                    int hh = (int) (22f * Math.min(1f, left / (float) total));
                    AbstractGui.fill(ms, x0, y0 + 22 - hh, x0 + 22, y0 + 22, 0xAA000000);
                    mc.font.drawShadow(ms, String.valueOf((left + 19) / 20), x0 + 8, y0 + 7, 0xFF5555);
                }
            }
        }
    }
}
