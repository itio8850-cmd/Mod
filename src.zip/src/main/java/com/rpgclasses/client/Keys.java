package com.rpgclasses.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.glfw.GLFW;

public class Keys {
    private static final String CAT = "key.categories.rpgclasses";
    public static final KeyBinding OPEN = new KeyBinding("key.rpgclasses.open", GLFW.GLFW_KEY_K, CAT);
    public static final KeyBinding SKILLS = new KeyBinding("key.rpgclasses.skills", GLFW.GLFW_KEY_J, CAT);
    public static final KeyBinding[] SKILL = new KeyBinding[6];

    static {
        int[] k = {GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_N};
        for (int i = 0; i < 6; i++) SKILL[i] = new KeyBinding("key.rpgclasses.skill" + (i + 1), k[i], CAT);
    }

    public static void register() {
        ClientRegistry.registerKeyBinding(OPEN);
        ClientRegistry.registerKeyBinding(SKILLS);
        for (KeyBinding kb : SKILL) ClientRegistry.registerKeyBinding(kb);
    }
}
