package com.rpgclasses.client;

import com.rpgclasses.RpgClassesMod;
import com.rpgclasses.data.ClientData;
import com.rpgclasses.net.ActionPacket;
import com.rpgclasses.net.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RpgClassesMod.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ClientData.ticks++;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (Keys.OPEN.consumeClick()) if (mc.screen == null) mc.setScreen(new RpgScreen());
        while (Keys.SKILLS.consumeClick()) if (mc.screen == null) mc.setScreen(new SkillScreen());
        for (int i = 0; i < 6; i++) {
            while (Keys.SKILL[i].consumeClick()) {
                if (mc.screen == null) ModNetwork.CH.sendToServer(new ActionPacket(3, new int[]{i}));
            }
        }
    }
}
