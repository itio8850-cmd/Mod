package com.rpgclasses;

import com.rpgclasses.data.Rank;
import com.rpgclasses.item.*;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.*;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.potion.Effects;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, RpgClassesMod.MODID);

    public static final ItemGroup TAB = new ItemGroup("rpgclasses") {
        @Override
        public ItemStack makeIcon() { return new ItemStack(get("espada_longa")); }
    };

    private static final SimpleTier IRON = new SimpleTier(600, 12, () -> Ingredient.of(Items.IRON_INGOT));
    private static final SimpleTier STEEL = new SimpleTier(1100, 14, () -> Ingredient.of(Items.DIAMOND));
    private static final SimpleTier TITAN = new SimpleTier(1800, 12, () -> Ingredient.of(Items.NETHERITE_INGOT));
    private static final SimpleTier MAGIC = new SimpleTier(900, 25, () -> Ingredient.of(Items.LAPIS_LAZULI));

    public static final RegistryObject<Item> RANK_STONE = ITEMS.register("pedra_ascensao", RankStone::new);

    static {
        // ---------- Corpo a corpo (dano, velocidade) ----------
        melee("espada_longa", IRON, 5, -2.4F, new GearSpec(Rank.E).stats(2, 0, 0, 0));
        melee("adaga_sombria", IRON, 2, -1.6F, new GearSpec(Rank.E).stats(0, 0, 3, 0));
        melee("machado_guerra", STEEL, 8, -3.2F, new GearSpec(Rank.D).stats(4, 1, 0, 0));
        melee("lanca_cacador", STEEL, 5, -2.0F, new GearSpec(Rank.D).stats(2, 0, 2, 0));
        melee("katana_carmesim", STEEL, 6, -1.8F, new GearSpec(Rank.C).stats(2, 0, 4, 0)
                .hit(() -> Effects.POISON, 60, 0));
        melee("espada_gelo", STEEL, 5, -2.4F, new GearSpec(Rank.C).stats(2, 0, 0, 2).skill(0.05F)
                .hit(() -> Effects.MOVEMENT_SLOWDOWN, 60, 1));
        melee("martelo_titan", TITAN, 10, -3.4F, new GearSpec(Rank.C).stats(5, 3, 0, 0)
                .hit(() -> Effects.MOVEMENT_SLOWDOWN, 60, 1));

        // ---------- Cajados (aumentam INT e poder de skills) ----------
        melee("cajado_arcano", MAGIC, 1, -2.4F, new GearSpec(Rank.E).stats(0, 0, 0, 4).skill(0.10F));
        melee("cajado_chamas", MAGIC, 2, -2.4F, new GearSpec(Rank.C).stats(1, 0, 0, 6).skill(0.20F));
        melee("cajado_vazio", MAGIC, 3, -2.4F, new GearSpec(Rank.A).stats(0, 2, 0, 9).skill(0.35F));

        // ---------- Arcos ----------
        ITEMS.register("arco_curto", () -> new RpgBow(500, new GearSpec(Rank.E).stats(0, 0, 3, 0).arrow(0.5)));
        ITEMS.register("arco_composto", () -> new RpgBow(900, new GearSpec(Rank.C).stats(1, 0, 5, 0).arrow(2.0)));
        ITEMS.register("arco_elfico", () -> new RpgBow(1400, new GearSpec(Rank.A).stats(0, 0, 8, 2).arrow(3.5)));

        // ---------- Talismãs (mão secundária) ----------
        ITEMS.register("talisma_forca", () -> new RpgTalisman(new GearSpec(Rank.D).stats(3, 0, 0, 0)));
        ITEMS.register("talisma_vento", () -> new RpgTalisman(new GearSpec(Rank.D).stats(0, 0, 3, 0)));
        ITEMS.register("talisma_sabedoria", () -> new RpgTalisman(new GearSpec(Rank.D).stats(0, 0, 0, 3).skill(0.08F)));
        ITEMS.register("talisma_vida", () -> new RpgTalisman(new GearSpec(Rank.D).stats(0, 4, 0, 0)));

        // ---------- Armaduras: defesa {botas, calças, peitoral, capacete} ----------
        armor("cacador", Rank.E, new int[]{2, 4, 5, 2}, 20, 0F, 0F, new int[]{0, 0, 2, 0}, 0F, () -> Ingredient.of(Items.RABBIT_HIDE));
        armor("arcano", Rank.E, new int[]{1, 2, 3, 1}, 15, 0F, 0F, new int[]{0, 0, 0, 2}, 0.03F, () -> Ingredient.of(Items.LAPIS_LAZULI));
        armor("placas_negras", Rank.D, new int[]{3, 6, 8, 3}, 35, 2F, 0.05F, new int[]{1, 2, 0, 0}, 0F, () -> Ingredient.of(Items.COAL_BLOCK));
        armor("sombria", Rank.C, new int[]{2, 4, 5, 2}, 28, 1F, 0F, new int[]{1, 0, 2, 0}, 0F, () -> Ingredient.of(Items.BLACK_WOOL));
        armor("sagrada", Rank.C, new int[]{3, 6, 7, 3}, 30, 1F, 0.02F, new int[]{0, 2, 0, 1}, 0.02F, () -> Ingredient.of(Items.QUARTZ));
        armor("dragao", Rank.B, new int[]{3, 6, 8, 3}, 40, 3F, 0.1F, new int[]{2, 2, 0, 1}, 0.03F, () -> Ingredient.of(Items.SCUTE));
    }

    private static void melee(String id, SimpleTier tier, int dmg, float speed, GearSpec spec) {
        ITEMS.register(id, () -> new RpgMelee(tier, dmg, speed, spec));
    }

    private static void armor(String set, Rank rank, int[] def, int dur, float tough, float kb, int[] st,
                              float skill, Supplier<Ingredient> repair) {
        RpgArmorMaterial mat = new RpgArmorMaterial(set, dur, def, tough, kb, repair);
        String[] names = {"botas", "calcas", "peitoral", "capacete"};
        EquipmentSlotType[] slots = {EquipmentSlotType.FEET, EquipmentSlotType.LEGS, EquipmentSlotType.CHEST, EquipmentSlotType.HEAD};
        for (int i = 0; i < 4; i++) {
            EquipmentSlotType slot = slots[i];
            ITEMS.register(set + "_" + names[i],
                    () -> new RpgArmor(mat, slot, new GearSpec(rank).stats(st[0], st[1], st[2], st[3]).skill(skill)));
        }
    }

    public static Item get(String id) {
        return ForgeRegistries.ITEMS.getValue(new ResourceLocation(RpgClassesMod.MODID, id));
    }
}
