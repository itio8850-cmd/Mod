package com.rpgclasses.item;

import com.rpgclasses.ModItems;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/** Talismã: dá bônus quando segurado na mão secundária (ou principal). */
public class RpgTalisman extends Item implements RpgGear {
    private final GearSpec spec;

    public RpgTalisman(GearSpec spec) {
        super(new Item.Properties().tab(ModItems.TAB).stacksTo(1).rarity(RpgGear.rarity(spec.rank)));
        this.spec = spec;
    }

    @Override public GearSpec spec() { return spec; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tip, ITooltipFlag flag) {
        addTooltip(tip);
        tip.add(new StringTextComponent("Segure na mão secundária").withStyle(TextFormatting.DARK_GRAY));
    }
}
