package com.rpgclasses.item;

import com.rpgclasses.ModItems;
import com.rpgclasses.data.RpgData;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.AbstractArrowEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class RpgBow extends BowItem implements RpgGear {
    private final GearSpec spec;

    public RpgBow(int durability, GearSpec spec) {
        super(new Item.Properties().tab(ModItems.TAB).durability(durability).rarity(RpgGear.rarity(spec.rank)));
        this.spec = spec;
    }

    @Override public GearSpec spec() { return spec; }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity p, Hand hand) {
        if (!usable(p)) {
            deny(p);
            return ActionResult.fail(p.getItemInHand(hand));
        }
        return super.use(world, p, hand);
    }

    @Override
    public AbstractArrowEntity customArrow(AbstractArrowEntity arrow) {
        if (arrow.getOwner() instanceof PlayerEntity) {
            RpgData d = RpgData.get((PlayerEntity) arrow.getOwner());
            arrow.setBaseDamage(arrow.getBaseDamage() + spec.arrowBonus + d.stats[2] * 0.25 + d.level * 0.02);
        }
        return arrow;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tip, ITooltipFlag flag) {
        addTooltip(tip);
    }
}
