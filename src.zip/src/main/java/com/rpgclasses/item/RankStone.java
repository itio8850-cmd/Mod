package com.rpgclasses.item;

import com.rpgclasses.ModItems;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class RankStone extends Item {
    public RankStone() { super(new Item.Properties().tab(ModItems.TAB).rarity(Rarity.EPIC).fireResistant()); }

    @Override public boolean isFoil(ItemStack s) { return true; }

    @Override
    public void appendHoverText(ItemStack s, @Nullable World w, List<ITextComponent> tip, ITooltipFlag f) {
        tip.add(new StringTextComponent("No level cap, abra a janela (K) e suba de Rank.").withStyle(TextFormatting.GRAY));
    }
}
