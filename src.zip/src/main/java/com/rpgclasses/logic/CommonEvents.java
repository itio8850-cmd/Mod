package com.rpgclasses.logic;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.rpgclasses.RpgClassesMod;
import com.rpgclasses.data.Rank;
import com.rpgclasses.data.RpgClass;
import com.rpgclasses.data.RpgData;
import com.rpgclasses.data.SkillMath;
import com.rpgclasses.item.RpgGear;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RpgClassesMod.MODID)
public class CommonEvents {

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) RpgLogic.refresh((ServerPlayerEntity) e.getPlayer());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        SkillCaster.forget(e.getPlayer().getUUID());
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) RpgLogic.refresh((ServerPlayerEntity) e.getPlayer());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        RpgData.get(e.getOriginal()).save(e.getPlayer());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) {
            ServerPlayerEntity p = (ServerPlayerEntity) e.getPlayer();
            RpgLogic.refresh(p);
            p.setHealth(p.getMaxHealth());
            RpgData d = RpgData.get(p);
            d.mana = d.maxMana;
            d.save(p);
            RpgLogic.sync(p, d);
        }
    }

    /** Trocar equipamento recalcula os bônus. */
    @SubscribeEvent
    public static void onEquip(LivingEquipmentChangeEvent e) {
        if (e.getEntityLiving() instanceof ServerPlayerEntity) {
            ServerPlayerEntity p = (ServerPlayerEntity) e.getEntityLiving();
            if (p.connection != null) RpgLogic.refresh(p);
        }
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayerEntity && !(e.getEntityLiving() instanceof PlayerEntity)) {
            RpgLogic.addXp((ServerPlayerEntity) e.getSource().getEntity(),
                    Math.max(1, (int) (e.getEntityLiving().getMaxHealth() / 2)));
        }
    }

    /** Arma de rank maior que o seu não causa dano. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        DamageSource src = e.getSource();
        if (src.getEntity() instanceof PlayerEntity && src.getDirectEntity() == src.getEntity()) {
            PlayerEntity p = (PlayerEntity) src.getEntity();
            Item it = p.getMainHandItem().getItem();
            if (it instanceof RpgGear && !((RpgGear) it).usable(p)) {
                e.setCanceled(true);
                ((RpgGear) it).deny(p);
            }
        }
    }

    /** Regeneração de mana (1x por segundo) + sincronização. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level.isClientSide) return;
        if (e.player.tickCount % 20 != 0) return;
        ServerPlayerEntity p = (ServerPlayerEntity) e.player;
        RpgData d = RpgData.get(p);
        if (d.rpgClass == RpgClass.NONE) return;
        GearUtil.Total g = GearUtil.of(p, d.rank);
        int intel = d.stats[3] + g.stats[3];
        float max = SkillMath.maxMana(d.rpgClass, d.level, intel);
        d.maxMana = max;
        if (d.mana < max) d.mana = Math.min(max, d.mana + SkillMath.regen(d.level, intel));
        d.save(p);
        RpgLogic.sync(p, d);
    }

    // ---------- Comandos de OP: /rpgreset, /rpglevel <n>, /rpgrank <E..S> ----------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("rpgreset").requires(s -> s.hasPermission(2)).executes(ctx -> {
            ServerPlayerEntity p = ctx.getSource().getPlayerOrException();
            new RpgData().save(p);
            RpgLogic.refresh(p);
            return 1;
        }));
        e.getDispatcher().register(Commands.literal("rpglevel").requires(s -> s.hasPermission(2))
                .then(Commands.argument("n", IntegerArgumentType.integer(1, 100)).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrException();
                    RpgData d = RpgData.get(p);
                    int n = Math.min(IntegerArgumentType.getInteger(ctx, "n"), d.cap());
                    if (n > d.level) d.points += (n - d.level) * RpgData.POINTS_PER_LEVEL;
                    d.level = n;
                    d.xp = 0;
                    d.save(p);
                    RpgLogic.refresh(p, d);
                    return 1;
                })));
        e.getDispatcher().register(Commands.literal("rpgrank").requires(s -> s.hasPermission(2))
                .then(Commands.argument("rank", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrException();
                    RpgData d = RpgData.get(p);
                    try {
                        d.rank = Rank.valueOf(StringArgumentType.getString(ctx, "rank").toUpperCase());
                    } catch (IllegalArgumentException ex) {
                        return 0;
                    }
                    d.level = Math.min(d.level, d.cap());
                    d.save(p);
                    RpgLogic.refresh(p, d);
                    return 1;
                })));
    }
}
