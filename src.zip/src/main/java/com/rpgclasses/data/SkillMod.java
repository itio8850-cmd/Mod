package com.rpgclasses.data;

/** Modificadores combináveis (até 3 por skill, depende do rank). */
public enum SkillMod {
    LIFESTEAL("Vampirismo", Rank.E, 6, 0, "Cura 35% do dano causado"),
    KNOCKBACK("Repulsão", Rank.E, 3, 0, "Empurra os alvos"),
    DASH("Investida", Rank.E, 5, 0, "Você avança na direção da mira"),
    HEAL("Cura", Rank.E, 10, 20, "Cura você"),
    HASTE("Velocidade", Rank.E, 5, 0, "Velocidade por 8s"),
    PULL("Atração", Rank.D, 4, 0, "Puxa os alvos até você"),
    STUN("Atordoar", Rank.D, 8, 20, "Imobiliza os alvos por 2s"),
    BLIND("Cegueira", Rank.D, 5, 0, "Cega os alvos"),
    POWER("Poder Máximo", Rank.D, 10, 30, "+50% de dano"),
    QUICK("Conj. Rápida", Rank.D, 4, 0, "Recarga -40%, dano -15%"),
    SHIELD("Escudo", Rank.D, 8, 20, "Absorção por 15s"),
    FURY("Fúria", Rank.D, 7, 0, "Força por 8s"),
    REGEN("Regeneração", Rank.D, 8, 20, "Regeneração por 6s"),
    LAUNCH("Arremessar", Rank.C, 6, 0, "Lança os alvos para cima"),
    EXECUTE("Executar", Rank.C, 8, 0, "+50% de dano em alvos com <30% de vida"),
    STEALTH("Furtividade", Rank.C, 8, 20, "Invisível por 5s");

    public final String display;
    public final Rank minRank;
    public final int mana, cdAdd;
    public final String desc;

    SkillMod(String display, Rank minRank, int mana, int cdAdd, String desc) {
        this.display = display;
        this.minRank = minRank;
        this.mana = mana;
        this.cdAdd = cdAdd;
        this.desc = desc;
    }
}
