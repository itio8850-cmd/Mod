package com.rpgclasses.data;

/** Uma skill montada pelo jogador: forma + elemento + até 3 modificadores. */
public class SkillSpec {
    public int shape, element;
    public int[] mods = {-1, -1, -1};

    public SkillSpec(int shape, int element) {
        this.shape = shape;
        this.element = element;
    }

    public static int slots(Rank r) { return Math.min(6, 2 + r.ordinal()); }
    public static int maxMods(Rank r) { return 1 + r.ordinal() / 2; }

    public Shape shape() { return Shape.values()[shape]; }
    public Element element() { return Element.values()[element]; }

    public boolean has(SkillMod m) {
        for (int x : mods) if (x == m.ordinal()) return true;
        return false;
    }

    public int manaCost() {
        int c = shape().mana + element().mana;
        for (int x : mods) if (x >= 0) c += SkillMod.values()[x].mana;
        return c;
    }

    public int cooldown() {
        int c = shape().cooldown;
        for (int x : mods) if (x >= 0) c += SkillMod.values()[x].cdAdd;
        if (has(SkillMod.QUICK)) c = Math.round(c * 0.6f);
        return Math.max(10, c);
    }

    public String name() {
        StringBuilder sb = new StringBuilder(shape().display);
        if (element() != Element.NONE) sb.append(" de ").append(element().display);
        for (int x : mods) if (x >= 0) sb.append(" +").append(SkillMod.values()[x].display);
        return sb.toString();
    }

    public int[] toArray() { return new int[]{shape, element, mods[0], mods[1], mods[2]}; }

    public static SkillSpec fromArray(int[] a) {
        if (a == null || a.length < 5) return null;
        if (a[0] < 0 || a[0] >= Shape.values().length || a[1] < 0 || a[1] >= Element.values().length) return null;
        SkillSpec s = new SkillSpec(a[0], a[1]);
        for (int i = 0; i < 3; i++) s.mods[i] = (a[2 + i] >= 0 && a[2 + i] < SkillMod.values().length) ? a[2 + i] : -1;
        return s;
    }
}
